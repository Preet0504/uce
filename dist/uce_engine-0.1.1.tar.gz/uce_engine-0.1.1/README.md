# Unified Context Engine (UCE)

UCE builds a deterministic knowledge graph of a codebase in Neo4j and exposes reasoning tools over that graph. It works across repositories, supports multiple languages, and continuously updates when files change.

This package is **pip-installable** and **CLI-friendly**.

## What UCE Does
- Ingests source code, schema, requirements, and policies into a Neo4j graph.
- Tracks files, functions, classes, methods, tables, columns, requirements, and policies.
- Provides deterministic impact analysis and risk assessment.
- Keeps the graph up-to-date via a file watcher.
- Exposes reasoning tools through an MCP server.

## Supported Languages
UCE uses Tree-sitter and supports:
- Python
- TypeScript
- JavaScript
- Go
- Java
- C
- C++

## Prerequisites
- **Python 3.10+** (recommended: 3.10 on Windows due to Tree-sitter wheels)
- **Neo4j** running locally or remotely

### Neo4j Setup (Local)
1. Install Neo4j Desktop or Neo4j Server.
2. Start a database and note the Bolt URI (default: `bolt://localhost:7687`).
3. Set a username and password.

### Neo4j Setup (Docker)
```bash
docker run --name neo4j-uce -p7474:7474 -p7687:7687 \
  -e NEO4J_AUTH=neo4j/testpassword \
  neo4j:5
```

## Install
```bash
pip install uce-engine
```

## Configure
Create a `config.yaml` file in any folder (recommended in the repo you want to analyze).

Example:
```yaml
project_root: ../talkai-main/

languages:
  - python
  - typescript
  - javascript
  - go
  - java
  - c
  - cpp

paths:
  code:
    - src
  schema:
    - src/db
  requirements:
    - src/requirements
  policies:
    - src/policies

ignore:
  - .git
  - .next
  - __pycache__
  - node_modules
  - venv
  - dist
  - build
  - coverage
  - .idea
  - .vscode
  - ui
  - views
  - public
  - assets
  - styles
  - css
  - scss
  - ".log"

aliases:
  "@/": src/

neo4j:
  uri: bolt://localhost:7687
  user: neo4j
  password: testpassword
```

### How `ignore` Works
`ignore` entries are **substring path filters** applied to relative file paths. If a file path contains `/ui/` or starts with `ui/`, it will be skipped.

Globs like `"*.log"` are treated as **literal substrings** unless you customize the matcher.

## Run (CLI)
From anywhere:
```bash
uce --config path/to/config.yaml
```

This will:
1. Load configuration
2. Connect to Neo4j
3. Build or update the graph
4. Start the file watcher
5. Launch the MCP server

## Run (Library)
```python
from uce import run_uce

run_uce("path/to/config.yaml")
```

## MCP Tools
UCE exposes reasoning tools via MCP:
- `impact_analysis`
- `explain_change`
- `risk_assessment`

These tools query the graph (no ingestion logic).

## What Nodes Are In The Graph
- `File`
- `Function`
- `Class`
- `Method`
- `Table`
- `Column`
- `Requirement`
- `Policy`

If you want additional node types (e.g., Dependencies, Endpoints, Services), add them in ingestion and reasoning layers.

## Typical Workflow
1. Install Neo4j and start it.
2. Create `config.yaml` pointing to your repo.
3. Run `uce --config config.yaml`.
4. Query the MCP server or Neo4j to explore the graph.

## Troubleshooting
**Neo4j auth error**
- Verify `neo4j.uri`, `neo4j.user`, `neo4j.password` in `config.yaml`.
- Make sure the database is running.

**Tree-sitter parser error on Windows**
- Use Python 3.10 in a clean venv.

**No schema/requirements/policies detected**
- Check `paths.schema`, `paths.requirements`, `paths.policies` in `config.yaml`.

## License
MIT
